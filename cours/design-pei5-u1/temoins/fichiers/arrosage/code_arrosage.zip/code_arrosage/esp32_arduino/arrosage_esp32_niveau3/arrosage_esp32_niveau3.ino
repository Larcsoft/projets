// Projet témoin : arrosage automatique du jardin - NIVEAU 3
// Design PEI 5 - Unités 1 et 2
// Carte : ESP32 DevKit V1, programmé avec Arduino IDE (même câblage que le niveau 2)
// Alimentation : 5 V uniquement
//
// Ce programme fait tout ce que fait le niveau 2, et en plus :
// - il prend l'heure sur Internet et arrose seulement tôt le matin ou le soir
//   (moins d'évaporation qu'en plein soleil) ;
// - il affiche une page web sur le téléphone : humidité, bidon, historique.

#include <WiFi.h>
#include <WebServer.h>
#include <time.h>

// ----- 1. Le Wi-Fi -----
const char* WIFI_NOM = "NOM_DU_WIFI";
const char* WIFI_MDP = "MOT_DE_PASSE";

// ----- 2. Les broches -----
int PIN_SOL = 34;
int PIN_NIVEAU = 35;
int PIN_NIV_ALIM = 33;
int PIN_RELAIS = 26;
int PIN_LED = 27;

// ----- 3. Les valeurs de calibration -----
int SOL_SEC = 3000;
int SOL_MOUILLE = 1300;
int NIVEAU_MIN = 800;

// ----- 4. Les réglages -----
int SEUIL_BAS = 35;
int SEUIL_HAUT = 55;
int CYCLES_MAX = 3;
long DUREE_POMPE = 8000;          // 8 secondes par dose
unsigned long ENTRE_MESURES = 300000;     // une mesure toutes les 5 minutes (c'est aussi le temps d'infiltration)

// ----- 5. Les variables qui changent pendant le programme -----
WebServer serveur(80);
int historique[24];               // les 24 dernières mesures (2 heures)
int nbMesures = 0;
int derniereHumidite = 0;
bool dernierBidonOK = true;
bool enArrosage = false;
int cycles = 0;
unsigned long derniereMesure = 0;


int lireMoyenne(int broche) {
  long somme = 0;
  int i = 0;
  while (i < 10) {
    somme = somme + analogRead(broche);
    delay(20);
    i = i + 1;
  }
  int moyenne = somme / 10;
  return moyenne;
}

int humiditeSol() {
  int brut = lireMoyenne(PIN_SOL);
  long ecart = SOL_SEC - brut;
  long pourcent = ecart * 100 / (SOL_SEC - SOL_MOUILLE);
  if (pourcent < 0) {
    pourcent = 0;
  }
  if (pourcent > 100) {
    pourcent = 100;
  }
  return pourcent;
}

bool reservoirOK() {
  digitalWrite(PIN_NIV_ALIM, HIGH);
  delay(50);
  int valeur = lireMoyenne(PIN_NIVEAU);
  digitalWrite(PIN_NIV_ALIM, LOW);
  if (valeur > NIVEAU_MIN) {
    return true;
  } else {
    return false;
  }
}

void arroser() {
  Serial.println("  Pompe ON");
  digitalWrite(PIN_RELAIS, HIGH);
  delay(DUREE_POMPE);
  digitalWrite(PIN_RELAIS, LOW);
  Serial.println("  Pompe OFF");
}

// Renvoie true entre 5 h et 9 h, ou entre 17 h et 20 h.
// Si l'heure n'est pas connue (pas de Wi-Fi), on autorise l'arrosage.
bool heureAutorisee() {
  struct tm maintenant;
  bool heureConnue = getLocalTime(&maintenant, 100);
  if (heureConnue == false) {
    return true;
  }
  int heure = maintenant.tm_hour;
  if (heure >= 5 && heure < 9) {
    return true;
  }
  if (heure >= 17 && heure < 20) {
    return true;
  }
  return false;
}

// Ajoute une mesure à la fin de l'historique.
// Quand il est plein, on décale tout d'une case vers la gauche.
void ajouterHistorique(int valeur) {
  if (nbMesures < 24) {
    historique[nbMesures] = valeur;
    nbMesures = nbMesures + 1;
  } else {
    int i = 0;
    while (i < 23) {
      historique[i] = historique[i + 1];
      i = i + 1;
    }
    historique[23] = valeur;
  }
}

// Fabrique la page web et l'envoie au téléphone
void pageAccueil() {
  String page = "<!DOCTYPE html><html><head><meta charset='utf-8'>";
  page = page + "<meta name='viewport' content='width=device-width'>";
  page = page + "<meta http-equiv='refresh' content='30'>";
  page = page + "<title>Arrosage</title></head><body style='font-family:sans-serif'>";
  page = page + "<h1>Arrosage du jardin</h1>";
  page = page + "<p>Humidité du sol : <b>" + String(derniereHumidite) + " %</b></p>";

  if (dernierBidonOK == true) {
    page = page + "<p>Bidon : <b>OK</b></p>";
  } else {
    page = page + "<p>Bidon : <b>VIDE, à remplir</b></p>";
  }

  if (heureAutorisee() == true) {
    page = page + "<p>Arrosage autorisé maintenant : oui</p>";
  } else {
    page = page + "<p>Arrosage autorisé maintenant : non</p>";
  }

  page = page + "<p>Historique (de la plus ancienne à la plus récente) :<br>";
  int i = 0;
  while (i < nbMesures) {
    page = page + String(historique[i]) + " %  ";
    i = i + 1;
  }
  page = page + "</p></body></html>";

  serveur.send(200, "text/html", page);
}


void setup() {
  pinMode(PIN_RELAIS, OUTPUT);
  digitalWrite(PIN_RELAIS, LOW);
  pinMode(PIN_LED, OUTPUT);
  pinMode(PIN_NIV_ALIM, OUTPUT);
  digitalWrite(PIN_NIV_ALIM, LOW);
  Serial.begin(115200);

  // Connexion au Wi-Fi : on essaie pendant 10 secondes au maximum
  WiFi.begin(WIFI_NOM, WIFI_MDP);
  int essais = 0;
  while (WiFi.status() != WL_CONNECTED && essais < 20) {
    delay(500);
    essais = essais + 1;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("Page web : http://");
    Serial.println(WiFi.localIP());
    configTime(0, 0, "pool.ntp.org");   // Lomé : heure GMT, pas d'heure d'été
  } else {
    Serial.println("Pas de Wi-Fi : le systeme marche quand meme, comme le niveau 2");
  }

  serveur.on("/", pageAccueil);
  serveur.begin();

  derniereMesure = millis() - ENTRE_MESURES;  // pour faire la première mesure tout de suite
}

void loop() {
  // 1. Répondre au téléphone s'il demande la page
  serveur.handleClient();

  // 2. Toutes les 5 minutes : mesurer et décider
  if (millis() - derniereMesure >= ENTRE_MESURES) {
    derniereMesure = millis();

    derniereHumidite = humiditeSol();
    dernierBidonOK = reservoirOK();
    ajouterHistorique(derniereHumidite);

    Serial.print("Humidite du sol = ");
    Serial.print(derniereHumidite);
    Serial.println(" %");

    if (dernierBidonOK == true) {
      digitalWrite(PIN_LED, LOW);
    } else {
      digitalWrite(PIN_LED, HIGH);
    }

    // Faut-il commencer à arroser ?
    if (enArrosage == false && derniereHumidite < SEUIL_BAS) {
      enArrosage = true;
      cycles = 0;
    }

    // Faut-il arrêter ?
    if (enArrosage == true && derniereHumidite >= SEUIL_HAUT) {
      enArrosage = false;
    }
    if (enArrosage == true && cycles >= CYCLES_MAX) {
      enArrosage = false;
    }

    // On donne une dose seulement si le bidon a de l'eau et si l'heure est bonne
    if (enArrosage == true && dernierBidonOK == true && heureAutorisee() == true) {
      arroser();
      cycles = cycles + 1;
    }
  }
}
