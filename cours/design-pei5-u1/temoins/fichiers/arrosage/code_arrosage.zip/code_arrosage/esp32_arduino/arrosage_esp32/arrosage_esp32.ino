// Projet témoin : arrosage automatique du jardin
// Design PEI 5 - Unités 1 et 2
// Carte : ESP32 DevKit V1, programmé avec Arduino IDE
// Alimentation : 5 V uniquement (câble USB ou chargeur USB 5 V)
//
// Niveau 1 : capteur d'humidité du sol + relais + mini-pompe 5 V
// Niveau 2 : + capteur de niveau d'eau dans le bidon + LED rouge d'alerte

// ----- 1. Les broches -----
int PIN_SOL = 34;        // capteur d'humidité (sortie AOUT)
int PIN_NIVEAU = 35;     // capteur de niveau d'eau (sortie S)
int PIN_NIV_ALIM = 33;   // alimente le capteur de niveau seulement pendant la mesure
int PIN_RELAIS = 26;     // entrée IN du module relais (cavalier sur H)
int PIN_LED = 27;        // LED rouge avec une résistance de 220 ohms

// ----- 2. Les valeurs de calibration (à mesurer avec TON capteur) -----
int SOL_SEC = 3000;      // valeur lue quand le capteur est dans l'air
int SOL_MOUILLE = 1300;  // valeur lue quand le capteur est dans un verre d'eau
int NIVEAU_MIN = 800;    // en dessous de cette valeur, le bidon est presque vide

// ----- 3. Les réglages -----
int NIVEAU_PROJET = 2;   // écrire 1 ou 2
int SEUIL_BAS = 35;      // en dessous de 35 %, on arrose
int SEUIL_HAUT = 55;     // à 55 %, on arrête
int CYCLES_MAX = 3;      // 3 doses au maximum, pour la sécurité

long DUREE_POMPE = 8000;     // 8 secondes de pompe par dose
long INFILTRATION = 20000;   // en classe : 20 s. Dans le jardin : 300000 (5 minutes)
long ENTRE_MESURES = 10000;  // en classe : 10 s. Dans le jardin : 1800000 (30 minutes)


// Lit 10 fois le capteur et renvoie la moyenne
int lireMoyenne(int broche) {
  long somme = 0;
  int i = 0;
  while (i < 10) {
    somme = somme + analogRead(broche);
    delay(20);
    i = i + 1;
  }
  int moyenne = somme / 10;
  return moyenne;
}

// Renvoie l'humidité du sol en % (0 = sec, 100 = dans l'eau)
int humiditeSol() {
  int brut = lireMoyenne(PIN_SOL);
  long ecart = SOL_SEC - brut;
  long pourcent = ecart * 100 / (SOL_SEC - SOL_MOUILLE);
  if (pourcent < 0) {
    pourcent = 0;
  }
  if (pourcent > 100) {
    pourcent = 100;
  }
  return pourcent;
}

// Renvoie true s'il reste assez d'eau dans le bidon
bool reservoirOK() {
  if (NIVEAU_PROJET == 1) {
    return true;                       // niveau 1 : pas de capteur de niveau
  }
  digitalWrite(PIN_NIV_ALIM, HIGH);    // on allume le capteur
  delay(50);
  int valeur = lireMoyenne(PIN_NIVEAU);
  digitalWrite(PIN_NIV_ALIM, LOW);     // on l'éteint : il s'abîme moins vite
  Serial.print("  Niveau du bidon = ");
  Serial.println(valeur);
  if (valeur > NIVEAU_MIN) {
    return true;
  } else {
    return false;
  }
}

// Fait marcher la pompe pendant une dose
void arroser() {
  Serial.println("  Pompe ON");
  digitalWrite(PIN_RELAIS, HIGH);
  delay(DUREE_POMPE);
  digitalWrite(PIN_RELAIS, LOW);
  Serial.println("  Pompe OFF");
}


void setup() {
  pinMode(PIN_RELAIS, OUTPUT);
  digitalWrite(PIN_RELAIS, LOW);       // la pompe est arrêtée au démarrage
  pinMode(PIN_LED, OUTPUT);
  pinMode(PIN_NIV_ALIM, OUTPUT);
  digitalWrite(PIN_NIV_ALIM, LOW);
  Serial.begin(115200);
  Serial.println("Arrosage automatique : demarrage");
}

void loop() {
  int h = humiditeSol();
  Serial.print("Humidite du sol = ");
  Serial.print(h);
  Serial.println(" %");

  bool eau = reservoirOK();
  if (eau == true) {
    digitalWrite(PIN_LED, LOW);
  } else {
    digitalWrite(PIN_LED, HIGH);       // le bidon est vide : alerte
  }

  if (h < SEUIL_BAS && eau == true) {
    int cycles = 0;
    while (h < SEUIL_HAUT && cycles < CYCLES_MAX && eau == true) {
      arroser();
      cycles = cycles + 1;
      delay(INFILTRATION);             // on laisse l'eau descendre dans la terre
      h = humiditeSol();
      Serial.print("  Apres la dose ");
      Serial.print(cycles);
      Serial.print(" : ");
      Serial.print(h);
      Serial.println(" %");
      eau = reservoirOK();
    }
    if (eau == false) {
      digitalWrite(PIN_LED, HIGH);
    }
  }

  delay(ENTRE_MESURES);
}
