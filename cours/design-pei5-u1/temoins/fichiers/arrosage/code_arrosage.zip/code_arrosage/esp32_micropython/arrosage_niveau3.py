# Projet témoin : arrosage automatique du jardin - NIVEAU 3
# Design PEI 5 - Unités 1 et 2
# Carte : ESP32 avec MicroPython (même câblage que le niveau 2)
# Pour que le programme démarre tout seul, l'enregistrer sur l'ESP32 sous le nom main.py
# Alimentation : 5 V uniquement
#
# Ce programme fait tout ce que fait le niveau 2, et en plus :
# - il prend l'heure sur Internet et arrose seulement tôt le matin ou le soir
#   (moins d'évaporation qu'en plein soleil) ;
# - il affiche une page web sur le téléphone : humidité, bidon, historique.

from machine import Pin, ADC
import time
import network
import socket
import ntptime

# ----- 1. Le Wi-Fi -----
WIFI_NOM = "NOM_DU_WIFI"
WIFI_MDP = "MOT_DE_PASSE"

# ----- 2. Les broches -----
capteur_sol = ADC(Pin(34))
capteur_sol.atten(ADC.ATTN_11DB)
capteur_niveau = ADC(Pin(35))
capteur_niveau.atten(ADC.ATTN_11DB)
alim_niveau = Pin(33, Pin.OUT)
relais = Pin(26, Pin.OUT)
led = Pin(27, Pin.OUT)

# ----- 3. Les valeurs de calibration -----
SOL_SEC = 3000
SOL_MOUILLE = 1300
NIVEAU_MIN = 800

# ----- 4. Les réglages -----
SEUIL_BAS = 35
SEUIL_HAUT = 55
CYCLES_MAX = 3
DUREE_POMPE = 8        # 8 secondes par dose
ENTRE_MESURES = 300    # une mesure toutes les 5 minutes (c'est aussi le temps d'infiltration)


def lire_moyenne(capteur):
    somme = 0
    i = 0
    while i < 10:
        somme = somme + capteur.read()
        time.sleep(0.02)
        i = i + 1
    moyenne = int(somme / 10)
    return moyenne


def humidite_sol():
    brut = lire_moyenne(capteur_sol)
    ecart = SOL_SEC - brut
    pourcent = int(ecart * 100 / (SOL_SEC - SOL_MOUILLE))
    if pourcent < 0:
        pourcent = 0
    if pourcent > 100:
        pourcent = 100
    return pourcent


def reservoir_ok():
    alim_niveau.value(1)
    time.sleep(0.05)
    valeur = lire_moyenne(capteur_niveau)
    alim_niveau.value(0)
    if valeur > NIVEAU_MIN:
        return True
    else:
        return False


def arroser():
    print("  Pompe ON")
    relais.value(1)
    time.sleep(DUREE_POMPE)
    relais.value(0)
    print("  Pompe OFF")


# Renvoie True entre 5 h et 9 h, ou entre 17 h et 20 h.
# Si l'heure n'est pas connue (pas de Wi-Fi), on autorise l'arrosage.
def heure_autorisee():
    if heure_connue == False:
        return True
    maintenant = time.localtime()
    heure = maintenant[3]
    if heure >= 5 and heure < 9:
        return True
    if heure >= 17 and heure < 20:
        return True
    return False


# Fabrique le texte de la page web
def fabriquer_page():
    page = "<!DOCTYPE html><html><head><meta charset='utf-8'>"
    page = page + "<meta name='viewport' content='width=device-width'>"
    page = page + "<meta http-equiv='refresh' content='30'>"
    page = page + "<title>Arrosage</title></head><body style='font-family:sans-serif'>"
    page = page + "<h1>Arrosage du jardin</h1>"
    page = page + "<p>Humidité du sol : <b>" + str(derniere_humidite) + " %</b></p>"

    if dernier_bidon_ok == True:
        page = page + "<p>Bidon : <b>OK</b></p>"
    else:
        page = page + "<p>Bidon : <b>VIDE, à remplir</b></p>"

    if heure_autorisee() == True:
        page = page + "<p>Arrosage autorisé maintenant : oui</p>"
    else:
        page = page + "<p>Arrosage autorisé maintenant : non</p>"

    page = page + "<p>Historique (de la plus ancienne à la plus récente) :<br>"
    for valeur in historique:
        page = page + str(valeur) + " %  "
    page = page + "</p></body></html>"
    return page


# ----- 5. Démarrage -----
relais.value(0)
alim_niveau.value(0)
led.value(0)

# Connexion au Wi-Fi : on essaie pendant 10 secondes au maximum
wifi = network.WLAN(network.STA_IF)
wifi.active(True)
wifi.connect(WIFI_NOM, WIFI_MDP)
essais = 0
while wifi.isconnected() == False and essais < 20:
    time.sleep(0.5)
    essais = essais + 1

heure_connue = False
if wifi.isconnected() == True:
    print("Page web : http://" + wifi.ifconfig()[0])
    try:
        ntptime.settime()              # Lomé : heure GMT, pas d'heure d'été
        heure_connue = True
    except OSError:
        print("Heure Internet non disponible")
else:
    print("Pas de Wi-Fi : le systeme marche quand meme, comme le niveau 2")

# Le serveur web : il attend au maximum 0,2 s qu'un téléphone se connecte
serveur = socket.socket()
serveur.bind(("0.0.0.0", 80))
serveur.listen(1)
serveur.settimeout(0.2)

# Les variables qui changent pendant le programme
historique = []                        # les 24 dernières mesures (2 heures)
derniere_humidite = 0
dernier_bidon_ok = True
en_arrosage = False
cycles = 0
derniere_mesure = time.time() - ENTRE_MESURES   # pour mesurer tout de suite

# ----- 6. Le programme principal -----
while True:
    # 1. Répondre au téléphone s'il demande la page
    try:
        client, adresse = serveur.accept()
        client.recv(1024)
        client.send("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n\r\n")
        client.send(fabriquer_page())
        client.close()
    except OSError:
        pass                           # personne n'a demandé la page : on continue

    # 2. Toutes les 5 minutes : mesurer et décider
    if time.time() - derniere_mesure >= ENTRE_MESURES:
        derniere_mesure = time.time()

        derniere_humidite = humidite_sol()
        dernier_bidon_ok = reservoir_ok()
        historique.append(derniere_humidite)
        if len(historique) > 24:
            historique.pop(0)          # on enlève la plus ancienne mesure
        print("Humidite du sol =", derniere_humidite, "%")

        if dernier_bidon_ok == True:
            led.value(0)
        else:
            led.value(1)

        # Faut-il commencer à arroser ?
        if en_arrosage == False and derniere_humidite < SEUIL_BAS:
            en_arrosage = True
            cycles = 0

        # Faut-il arrêter ?
        if en_arrosage == True and derniere_humidite >= SEUIL_HAUT:
            en_arrosage = False
        if en_arrosage == True and cycles >= CYCLES_MAX:
            en_arrosage = False

        # On donne une dose seulement si le bidon a de l'eau et si l'heure est bonne
        if en_arrosage == True and dernier_bidon_ok == True and heure_autorisee() == True:
            arroser()
            cycles = cycles + 1
