# Projet témoin : arrosage automatique du jardin
# Design PEI 5 - Unités 1 et 2
# Carte : ESP32 avec MicroPython (programmé avec Thonny)
# Pour que le programme démarre tout seul, l'enregistrer sur l'ESP32 sous le nom main.py
# Alimentation : 5 V uniquement (câble USB ou chargeur USB 5 V)
#
# Niveau 1 : capteur d'humidité du sol + relais + mini-pompe 5 V
# Niveau 2 : + capteur de niveau d'eau dans le bidon + LED rouge d'alerte

from machine import Pin, ADC
import time

# ----- 1. Les broches -----
capteur_sol = ADC(Pin(34))           # capteur d'humidité (sortie AOUT)
capteur_sol.atten(ADC.ATTN_11DB)     # pour mesurer de 0 à 3,3 V
capteur_niveau = ADC(Pin(35))        # capteur de niveau d'eau (sortie S)
capteur_niveau.atten(ADC.ATTN_11DB)
alim_niveau = Pin(33, Pin.OUT)       # alimente le capteur de niveau seulement pendant la mesure
relais = Pin(26, Pin.OUT)            # entrée IN du module relais (cavalier sur H)
led = Pin(27, Pin.OUT)               # LED rouge avec une résistance de 220 ohms

# ----- 2. Les valeurs de calibration (à mesurer avec TON capteur) -----
SOL_SEC = 3000         # valeur lue quand le capteur est dans l'air
SOL_MOUILLE = 1300     # valeur lue quand le capteur est dans un verre d'eau
NIVEAU_MIN = 800       # en dessous de cette valeur, le bidon est presque vide

# ----- 3. Les réglages -----
NIVEAU_PROJET = 2      # écrire 1 ou 2
SEUIL_BAS = 35         # en dessous de 35 %, on arrose
SEUIL_HAUT = 55        # à 55 %, on arrête
CYCLES_MAX = 3         # 3 doses au maximum, pour la sécurité
DUREE_POMPE = 8        # 8 secondes de pompe par dose
INFILTRATION = 20      # en classe : 20 s. Dans le jardin : 300 (5 minutes)
ENTRE_MESURES = 10     # en classe : 10 s. Dans le jardin : 1800 (30 minutes)


# Lit 10 fois le capteur et renvoie la moyenne
def lire_moyenne(capteur):
    somme = 0
    i = 0
    while i < 10:
        somme = somme + capteur.read()
        time.sleep(0.02)
        i = i + 1
    moyenne = int(somme / 10)
    return moyenne


# Renvoie l'humidité du sol en % (0 = sec, 100 = dans l'eau)
def humidite_sol():
    brut = lire_moyenne(capteur_sol)
    ecart = SOL_SEC - brut
    pourcent = int(ecart * 100 / (SOL_SEC - SOL_MOUILLE))
    if pourcent < 0:
        pourcent = 0
    if pourcent > 100:
        pourcent = 100
    return pourcent


# Renvoie True s'il reste assez d'eau dans le bidon
def reservoir_ok():
    if NIVEAU_PROJET == 1:
        return True                    # niveau 1 : pas de capteur de niveau
    alim_niveau.value(1)               # on allume le capteur
    time.sleep(0.05)
    valeur = lire_moyenne(capteur_niveau)
    alim_niveau.value(0)               # on l'éteint : il s'abîme moins vite
    print("  Niveau du bidon =", valeur)
    if valeur > NIVEAU_MIN:
        return True
    else:
        return False


# Fait marcher la pompe pendant une dose
def arroser():
    print("  Pompe ON")
    relais.value(1)
    time.sleep(DUREE_POMPE)
    relais.value(0)
    print("  Pompe OFF")


# ----- 4. Le programme principal -----
relais.value(0)        # la pompe est arrêtée au démarrage
alim_niveau.value(0)
led.value(0)
print("Arrosage automatique : demarrage")

while True:
    h = humidite_sol()
    print("Humidite du sol =", h, "%")

    eau = reservoir_ok()
    if eau == True:
        led.value(0)
    else:
        led.value(1)                   # le bidon est vide : alerte

    if h < SEUIL_BAS and eau == True:
        cycles = 0
        while h < SEUIL_HAUT and cycles < CYCLES_MAX and eau == True:
            arroser()
            cycles = cycles + 1
            time.sleep(INFILTRATION)   # on laisse l'eau descendre dans la terre
            h = humidite_sol()
            print("  Apres la dose", cycles, ":", h, "%")
            eau = reservoir_ok()
        if eau == False:
            led.value(1)

    time.sleep(ENTRE_MESURES)
