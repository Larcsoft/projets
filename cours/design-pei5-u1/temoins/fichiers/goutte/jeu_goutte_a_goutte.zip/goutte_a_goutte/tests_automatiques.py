# Tests automatiques du jeu témoin « Goutte à goutte » (preuves pour C2, C3, D1 et D2).
#
# Lancer : python tests_automatiques.py
# Le script joue des parties sans fenêtre avec trois joueurs simulés,
# mesure la vitesse d'affichage et enregistre des captures d'écran dans captures/.
# Outil de l'enseignant(e) : les élèves n'ont pas besoin de le comprendre.

import os
import random
import time

os.environ["SDL_VIDEODRIVER"] = "dummy"
import pygame

DOSSIER = os.path.dirname(os.path.abspath(__file__))
DOSSIER_CAPTURES = os.path.join(DOSSIER, "captures")
DT = 1 / 30

# Charger le jeu sans lancer sa dernière ligne main()
chemin_jeu = os.path.join(DOSSIER, "goutte_a_goutte.py")
fichier = open(chemin_jeu, "r", encoding="utf-8")
code = fichier.read()
fichier.close()
code = code.replace("\nmain()\n", "\n")
jeu = {}
exec(code, jeu)


def aller_vers(x, y):
    # Renvoie gauche, droite, haut, bas pour rejoindre le point (x, y)
    centre_x = jeu["jardinier_x"] + 15
    centre_y = jeu["jardinier_y"] + 20
    gauche = centre_x > x + 5
    droite = centre_x < x - 5
    haut = centre_y > y + 5
    bas = centre_y < y - 5
    return gauche, droite, haut, bas


def centre_planche(planche):
    return planche["x"] + 75, planche["y"] + 45


def joueur_econome(memoire):
    # Arrose la planche la plus sèche sous 45 %, jamais sous la pluie, remplit au puits.
    if jeu["arrosoir"] == 0 or memoire["au_puits"] == True:
        memoire["au_puits"] = True
        if jeu["pres_du_puits"]() == True:
            jeu["remplir"]()
            memoire["au_puits"] = False
            return False, False, False, False
        return aller_vers(jeu["PUITS_X"], jeu["PUITS_Y"])
    cible = None
    for planche in jeu["planches"]:
        if planche["morte"] == False:
            if cible == None or planche["humidite"] < cible["humidite"]:
                cible = planche
    if cible == None or cible["humidite"] > 45 or jeu["il_pleut"]() == True:
        return False, False, False, False
    if jeu["planche_touchee"]() is cible:
        memoire["pause"] = memoire["pause"] + 1
        if memoire["pause"] % 6 == 0 and cible["humidite"] <= 80:
            jeu["arroser"]()
        return False, False, False, False
    x, y = centre_planche(cible)
    return aller_vers(x, y)


def joueur_gaspilleur(memoire):
    # Arrose dès qu'il touche une planche, sans regarder la jauge ni la météo.
    if jeu["arrosoir"] == 0:
        if jeu["pres_du_puits"]() == True:
            jeu["remplir"]()
            return False, False, False, False
        return aller_vers(jeu["PUITS_X"], jeu["PUITS_Y"])
    cible = jeu["planches"][memoire["i"] % 6]
    if jeu["planche_touchee"]() is cible:
        jeu["arroser"]()
        memoire["i"] = memoire["i"] + 1
        return False, False, False, False
    x, y = centre_planche(cible)
    return aller_vers(x, y)


def joueur_inactif(memoire):
    return False, False, False, False


def capture(nom):
    ecran = pygame.Surface((800, 600))
    jeu["dessiner"](ecran)
    pygame.image.save(ecran, os.path.join(DOSSIER_CAPTURES, nom))


def jouer(joueur, graine, captures):
    random.seed(graine)
    jeu["NIVEAU"] = 3
    jeu["reinitialiser"]()
    jeu["meilleur_score"] = 1000000  # ne pas écraser le vrai meilleur score
    memoire = {"au_puits": False, "pause": 0, "i": 0}
    images = 0
    while jeu["fini"] == False:
        gauche, droite, haut, bas = joueur(memoire)
        jeu["mettre_a_jour"](DT, gauche, droite, haut, bas)
        images = images + 1
        for instant in list(captures.keys()):
            if jeu["temps"] >= instant:
                nom, message = captures[instant]
                if message != "":
                    jeu["afficher_message"](message)
                capture(nom)
                del captures[instant]
    return images * DT


def mesurer_images_par_seconde():
    ecran = pygame.display.set_mode((800, 600))
    jeu["reinitialiser"]()
    debut = time.perf_counter()
    for i in range(300):
        jeu["mettre_a_jour"](DT, False, False, False, False)
        jeu["dessiner"](ecran)
        pygame.display.flip()
    return 300 / (time.perf_counter() - debut)


def main():
    pygame.init()
    jeu["preparer_polices"]()
    os.makedirs(DOSSIER_CAPTURES, exist_ok=True)
    print("Joueur        | Partie | Durée (s) | Vivantes | Versé (L) | Gaspillé (L) | Gaspillé % | Étoiles")
    joueurs = [("économe", joueur_econome), ("gaspilleur", joueur_gaspilleur), ("inactif", joueur_inactif)]
    for nom, joueur in joueurs:
        total = 0
        for graine in range(1, 6):
            duree = jouer(joueur, graine, {})
            total = total + jeu["pourcentage_gaspille"]()
            print("%-13s | %6d | %9.1f | %8d | %9.0f | %12.1f | %10d | %d" % (
                nom, graine, duree, jeu["plantes_vivantes"](), jeu["litres_verses"],
                jeu["litres_gaspilles"], jeu["pourcentage_gaspille"](), jeu["nombre_etoiles"]()))
        print("%-13s | moyenne du gaspillage : %.0f %%" % (nom, total / 5))
    print("Vitesse d'affichage : %.0f images par seconde (objectif : 30)" % mesurer_images_par_seconde())
    print("Taille du programme : %.1f Ko, aucun fichier image ou son" % (os.path.getsize(chemin_jeu) / 1024))

    # Captures d'écran pour la trace
    jouer(joueur_econome, 3, {5: ("capture_matin.png", ""),
                              50: ("capture_midi.png", "La moitié de l'eau s'évapore à midi")})
    random.seed(3)
    jeu["reinitialiser"]()
    jeu["temps"] = jeu["pluie_debut"] + 2
    jeu["afficher_message"]("Gaspillage : il pleut déjà !")
    capture("capture_pluie.png")
    jouer(joueur_econome, 3, {})
    jeu["meilleur_score"] = jeu["calculer_score"]()
    capture("capture_bilan.png")
    for niveau in [1, 2]:
        jeu["NIVEAU"] = niveau
        jeu["reinitialiser"]()
        jeu["mettre_a_jour"](DT, False, False, False, False)
        capture("capture_niveau" + str(niveau) + ".png")
    print("Captures enregistrées dans", DOSSIER_CAPTURES)
    pygame.quit()


main()
